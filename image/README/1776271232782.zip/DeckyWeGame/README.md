# WeGame Launcher

一款运行在 SteamOS / Steam Deck 上的独立桌面应用，用于在 Linux 环境下配置和启动腾讯 WeGame 游戏平台。

## 功能特性

- **环境初始化** - 一键创建独立的 Wine/Proton 兼容前缀
- **Proton 管理** - 自动检测 GE-Proton 版本，支持手动选择
- **依赖安装** - 通过 winetricks 自动安装 .NET Framework、VC++ 运行时、中文字体等组件
- **WeGame 启停** - 配置完整环境变量，一键启动/停止 WeGame
- **游戏库管理** - 扫描已安装游戏，支持添加到 Steam 库
- **高级设置** - 自定义路径、环境变量、启动参数

## 技术栈

- **前端**: React 18 + TypeScript + TailwindCSS
- **后端**: Tauri v2 (Rust)
- **构建工具**: Vite 5 + Cargo

---

## 安装与构建

### 一键安装

在 Steam Deck 上进入桌面模式（长按电源键 → Switch to Desktop），打开 **Konsole** 终端，执行：

```bash
# 将项目克隆到桌面
cd ~/Desktop
git clone https://github.com/你的用户名/DeckyWeGame.git
cd DeckyWeGame

# 一键安装并构建
chmod +x install.sh
./install.sh
```

脚本会自动完成以下操作（已安装的组件会自动跳过）：

| 步骤 | 说明 |
|------|------|
| 关闭只读文件系统 | `steamos-readonly disable` |
| 安装系统依赖 | webkit2gtk、libgtk-3、openssl 等（通过 pacman） |
| 安装 Rust | rustup（如已安装则更新） |
| 安装 Node.js | 通过 pacman |
| 安装 pnpm | 通过 npm 或 corepack |
| 安装 winetricks | WeGame 依赖安装工具 |
| 构建项目 | `pnpm install` + `pnpm tauri build` |
| 创建桌面快捷方式 | 生成 .desktop 文件 |
| 恢复只读保护 | `steamos-readonly enable`（可选） |

> 首次构建 Rust 编译较慢，约需 5-15 分钟，取决于设备性能。

### 构建完成后

- 双击桌面上的 **WeGame Launcher** 图标启动
- 或在终端直接运行生成的 `.AppImage` 文件

### 添加到 Steam（可选）

1. 打开 Steam
2. 左下角 **"添加游戏"** → **"添加非 Steam 游戏"**
3. 浏览到 `~/Desktop/DeckyWeGame/src-tauri/target/release/bundle/appimage/` 下的 `.AppImage` 文件
4. 添加后可在游戏模式中直接启动

---

## 使用说明

1. 打开应用后进入「环境设置」向导
2. 选择 Proton 版本（推荐 GE-Proton）
3. 确认路径和要安装的依赖组件
4. 执行安装（可能需要 10-30 分钟）
5. 安装完成后点击「启动器」→「启动 WeGame」
6. 在「启动器」中扫描游戏并添加到 Steam 库

## 项目结构

```
DeckyWeGame/
├── install.sh          # 一键安装脚本
├── src-tauri/src/      # Rust 后端
│   ├── main.rs         # 应用入口
│   ├── commands.rs     # IPC 命令定义
│   ├── config.rs       # 配置文件管理
│   ├── environment.rs  # Wine Prefix 操作
│   ├── proton.rs       # Proton 版本检测
│   ├── dependencies.rs # winetricks 依赖安装
│   ├── launcher.rs     # 进程启停管理
│   └── steam.rs        # Steam 快捷方式生成
├── src/                # React 前端
│   ├── pages/          # 页面组件
│   ├── components/     # 可复用 UI 组件
│   ├── hooks/          # 自定义 Hooks
│   └── utils/          # 常量和辅助函数
└── package.json        # 前端依赖配置
```

## License

MIT
