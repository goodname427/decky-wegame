#!/bin/bash
# ============================================================
#  WeGame Launcher - SteamOS 一键安装与构建脚本
#  用法: chmod +x install.sh && ./install.sh
# ============================================================

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

# 项目信息
PROJECT_NAME="WeGame Launcher"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

log_info()    { echo -e "${CYAN}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[OK]${NC} $1"; }
log_warn()    { echo -e "${YELLOW}[WARN]${NC} $1"; }
log_error()   { echo -e "${RED}[ERROR]${NC} $1"; }
log_step()    { echo -e "\n${BOLD}${CYAN}━━━ $1 ━━━${NC}\n"; }

# 检查是否为 SteamOS
check_os() {
    log_step "检查系统环境"
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        if echo "$ID $ID_LIKE" | grep -qi "steamos\|arch\|manjaro"; then
            log_success "当前系统: $PRETTY_NAME"
        else
            log_warn "当前系统: $PRETTY_NAME（非 SteamOS/Arch，部分命令可能不兼容）"
        fi
    else
        log_warn "无法检测系统版本，继续执行..."
    fi
}

# 关闭只读文件系统
disable_readonly() {
    log_step "关闭 SteamOS 只读文件系统"
    if sudo steamos-readonly status 2>/dev/null | grep -q "enabled"; then
        log_info "正在关闭只读模式..."
        sudo steamos-readonly disable
        log_success "只读模式已关闭"
    else
        log_success "只读模式已经是关闭状态"
    fi
}

# 安装系统依赖
install_system_deps() {
    log_step "安装系统依赖"
    local deps=(
        webkit2gtk-4.1
        libappindicator-gtk3
        librsvg
        libgtk-3
        openssl
        pkg-config
        patchelf
        file
        git
        base-devel
    )

    log_info "即将安装: ${deps[*]}"
    sudo pacman -Sy --noconfirm --needed "${deps[@]}"
    log_success "系统依赖安装完成"
}

# 安装 Rust
install_rust() {
    log_step "安装 Rust 工具链"
    if command -v rustc &>/dev/null; then
        local rust_ver
        rust_ver=$(rustc --version 2>/dev/null || echo "未知")
        log_success "Rust 已安装: $rust_ver"
        # 更新到最新稳定版
        log_info "更新 Rust 到最新版本..."
        rustup update stable
    else
        log_info "正在下载并安装 Rust..."
        curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
        source "$HOME/.cargo/env"
        log_success "Rust 安装完成: $(rustc --version)"
    fi
}

# 安装 Node.js
install_node() {
    log_step "安装 Node.js"
    if command -v node &>/dev/null; then
        log_success "Node.js 已安装: $(node --version)"
    else
        log_info "正在通过 pacman 安装 Node.js..."
        sudo pacman -S --noconfirm --needed nodejs
        log_success "Node.js 安装完成: $(node --version)"
    fi
}

# 安装 pnpm
install_pnpm() {
    log_step "安装 pnpm"
    if command -v pnpm &>/dev/null; then
        log_success "pnpm 已安装: $(pnpm --version)"
    else
        # 优先尝试 npm install
        if command -v npm &>/dev/null; then
            log_info "正在通过 npm 安装 pnpm..."
            npm install -g pnpm
            log_success "pnpm 安装完成: $(pnpm --version)"
        # 其次尝试 corepack
        elif command -v corepack &>/dev/null; then
            log_info "正在通过 corepack 启用 pnpm..."
            corepack enable
            corepack prepare pnpm@latest --activate
            log_success "pnpm 安装完成: $(pnpm --version)"
        else
            log_error "无法安装 pnpm（npm 和 corepack 均不可用）"
            exit 1
        fi
    fi
}

# 安装 winetricks
install_winetricks() {
    log_step "安装 winetricks"
    if command -v winetricks &>/dev/null; then
        log_success "winetricks 已安装"
    else
        log_info "正在安装 winetricks..."
        sudo pacman -S --noconfirm --needed winetricks
        log_success "winetricks 安装完成"
    fi
}

# 安装前端依赖并构建
build_project() {
    log_step "构建项目"

    cd "$SCRIPT_DIR"

    # 安装前端依赖
    log_info "安装前端依赖 (pnpm install)..."
    pnpm install

    # 构建 Tauri 应用
    log_info "正在编译（首次构建可能需要 5-15 分钟）..."
    pnpm tauri build

    # 找到产物
    local appimage
    appimage=$(find src-tauri/target/release/bundle/appimage/ -name "*.AppImage" 2>/dev/null | head -1)

    if [ -n "$appimage" ] && [ -f "$appimage" ]; then
        log_success "构建成功！"
        echo ""
        echo -e "${GREEN}${BOLD}━━━ 构建产物 ━━━${NC}"
        echo -e "  AppImage: ${CYAN}${appimage}${NC}"
        echo ""

        # 创建桌面快捷方式
        create_desktop_entry "$appimage"

        # 提示添加到 Steam
        echo -e "${YELLOW}${BOLD}如需添加到 Steam 库：${NC}"
        echo -e "  1. 打开 Steam → 左下角「添加游戏」→「添加非 Steam 游戏」"
        echo -e "  2. 浏览到: ${CYAN}${appimage}${NC}"
        echo ""
    else
        log_error "构建完成但未找到 AppImage 产物，请检查上方日志"
        exit 1
    fi
}

# 创建桌面快捷方式
create_desktop_entry() {
    local appimage="$1"
    local desktop_file="$HOME/Desktop/wegame-launcher.desktop"

    log_info "创建桌面快捷方式..."

    cat > "$desktop_file" << EOF
[Desktop Entry]
Name=WeGame Launcher
Comment=在 SteamOS 上运行腾讯 WeGame
Exec="$appimage" %U
Icon=steamdeck-gaming-return
Terminal=false
Type=Application
Categories=Game;
StartupNotify=true
EOF

    chmod +x "$desktop_file"
    # SteamOS 桌面需要信任
    if command -v gio &>/dev/null; then
        gio set "$desktop_file" metadata::trusted true 2>/dev/null || \
        sed -i 's/^Type=Application$/&\nX-Flatpak=n/' "$desktop_file" 2>/dev/null || true
    fi
    chmod +x "$desktop_file"

    log_success "桌面快捷方式已创建: $desktop_file"
}

# 提示恢复只读
prompt_readonly() {
    echo -e "${YELLOW}${BOLD}━━━ 安全提示 ━━━${NC}"
    echo -e "  构建已完成。建议恢复 SteamOS 只读保护以保障系统安全："
    echo -e "    ${CYAN}sudo steamos-readonly enable${NC}"
    echo ""
    read -rp "$(echo -e ${YELLOW}是否现在恢复只读模式？[Y/n] ${NC})" choice
    choice=${choice:-Y}
    if [[ "$choice" =~ ^[Yy]$ ]]; then
        sudo steamos-readonly enable
        log_success "只读模式已恢复"
    else
        log_warn "跳过恢复只读模式（请手动执行 sudo steamos-readonly enable）"
    fi
}

# ============================================================
#  主流程
# ============================================================

main() {
    echo -e "${BOLD}${CYAN}"
    echo "  ╔══════════════════════════════════════╗"
    echo "  ║     WeGame Launcher 安装向导         ║"
    echo "  ║     SteamOS / Steam Deck             ║"
    echo "  ╚══════════════════════════════════════╝"
    echo -e "${NC}"

    check_os
    disable_readonly
    install_system_deps
    install_rust
    install_node
    install_pnpm
    install_winetricks
    build_project
    prompt_readonly

    echo -e "\n${GREEN}${BOLD}━━━ 全部完成！━━━${NC}\n"
    echo -e "  双击桌面上的 ${CYAN}WeGame Launcher${NC} 图标即可启动"
    echo -e "  或在终端运行: ${CYAN}${appimage:-./WeGame_Launcher.AppImage}${NC}\n"
}

main "$@"
